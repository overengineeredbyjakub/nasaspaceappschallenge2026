'use strict';
(function(){

/* ================================================================
   ATLAS MISJI — Mars & Księżyc (NASA Space Apps)
   Dane zewnętrzne: nasa_data.json, tekstury: NASA TREK WMTS,
   sites/traverses: azmth.space (+ lokalny cache assets/api),
   dane popupów: assets/dumps/*.json (zdumpowane strony NASA),
   niebo: assets/skybox.exr | assets/skybox.jpg (NASA SVS Deep Star Maps).
   ================================================================ */

/* =================== dane =================== */
var DATA=null, PLANETS=null, META=null, TYPE_PL=null, ALIAS=null, DUMPS=null, HISTORY=null;
var API='', TREK='', WMTS='';
function trekUrl(path){ return TREK + path + '/' + WMTS; }

var $ = function(id){ return document.getElementById(id); };
function esc(t){ return String(t==null?'':t).replace(/[&<>"]/g, function(c){
  return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
function fmtDate(d){
  if(!d) return '—';
  if(typeof d==='number') return String(d);
  if(/^\d{4}$/.test(d)) return d;
  var m = d.match(/^(\d{4})-(\d{2})(?:-(\d{2}))?/);
  if(!m) return d;
  var M = ['','sty','lut','mar','kwi','maj','cze','lip','sie','wrz','paź','lis','gr'][+m[2]] || m[2];
  return m[1] + ' ' + M + (m[3]? ' ' + (+m[3]) : '');
}
function yearOf(s){ if(!s) return null; var m = String(s).match(/^(\d{4})/); return m? +m[1] : (typeof s==='number'? s : null); }
function fmtISO(y){
  var yi = Math.floor(y);
  var d = new Date(Date.UTC(yi, 0, 1));
  d.setUTCDate(d.getUTCDate() + Math.floor((y - yi) * 365.25));
  return d.toISOString().slice(0,10);
}
function firstSentences(t, n){
  var m = String(t).match(/[^.]+\./g);
  if(!m || m.length===0) return String(t);
  return m.slice(0, n).join(' ').trim();
}

var ICONS = {
  rover:'<i class="ph ph-robot"></i>',
  'soft-lander':'<i class="ph ph-airplane-landing"></i>',
  helicopter:'<i class="ph ph-drone"></i>',
  impactor:'<i class="ph ph-bullseye"></i>',
  orbiter:'<i class="ph ph-globe"></i>',
  artefact:'<i class="ph ph-cube"></i>',
  'crewed-landing':'<i class="ph ph-person"></i>',
  'crewed-flyby':'<i class="ph ph-person"></i>',
  debris:'<i class="ph ph-broom"></i>',
  topic:'<i class="ph ph-info"></i>'
};
function iconFor(t){ return ICONS[t] || ICONS.artefact; }

/* =================== stan =================== */
var planet=null, planetKey='mars';
var sites=[];               // znormalizowane wpisy
var events=[];              // {y, s} — zdarzenia osi czasu
var selected=null;
var year=2026;              // rok wyliczany z pozycji suwaka
var tPos=0;                 // pozycja suwaka w przestrzeni indeksów zdarzeń
var lastScrubIdx=-1;        // ostatni indek wybrany suwakiem (anti-repeat)
var playing=false, slide=null, dwellT=0;
var fQ='';                  // fraza wyszukiwania
var traverseData=null, traverseCache={}, routePlay=null;
var camAnim=null;
var hdTex={mars:{normal:null,heat:null}, moon:{normal:null,heat:null}};
var texKind='normal';       // 'normal' | 'heat' (heatmapa wysokości)
var flatMode=false, reliefOn=false;
var texCache={mars:{normal:{},heat:{}}, moon:{normal:{},heat:{}}};
var globeCanvas={mars:null, moon:null};
var heightData={}, heightCache={}, reliefGeoms={};
var appliedL={mars:0, moon:0};
var skyMesh=null, skyReady=false, bootDone=false;
var autoRotateOn=true;
var viewShiftOn=false;
var rotMap={};              // aktywne interwały obrotu 180° markerów

/* =================== scena =================== */
var canvas = $('gl');
var renderer = new THREE.WebGLRenderer({canvas:canvas, antialias:true, logarithmicDepthBuffer:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2));
var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera(45, 1, 0.05, 100);
camera.position.set(0, 0.9, 2.7);
scene.add(new THREE.AmbientLight(0xffffff, 0.85));
var dl = new THREE.DirectionalLight(0xffffff, 0.35); dl.position.set(2,1.5,3); scene.add(dl);

var controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.dampingFactor = 0.08;
controls.minDistance = 1.02; controls.maxDistance = 6;
controls.enablePan = false;
controls.autoRotate = true; controls.autoRotateSpeed = 0.35;

var baseTex = proceduralTexture('#b0532a','mars');
var globe = new THREE.Mesh(
  new THREE.SphereGeometry(1, 128, 96),
  new THREE.MeshPhongMaterial({color:0xffffff, shininess:5, specular:0x222222,
    map:baseTex, bumpMap:baseTex, bumpScale:0})
);
scene.add(globe);
var baseGeom = globe.geometry;
var markerLayer = $('markers');
var frameEl = $('frame');
var routeGroup = new THREE.Group(); scene.add(routeGroup);
var headMarker = new THREE.Mesh(new THREE.SphereGeometry(0.0075, 12, 10),
  new THREE.MeshBasicMaterial({color:0xffffff}));
headMarker.visible = false; scene.add(headMarker);
var popupEl = $('popup');

function latLonToVec3(lat, lon, r){
  var phi = (90 - lat) * Math.PI/180;
  var th  = (lon + 180) * Math.PI/180;
  return new THREE.Vector3(
    -r * Math.sin(phi) * Math.cos(th),
     r * Math.cos(phi),
     r * Math.sin(phi) * Math.sin(th));
}
function latLonInto(out, lat, lon, r){
  var phi = (90 - lat) * Math.PI/180;
  var th  = (lon + 180) * Math.PI/180;
  out.set(
    -r * Math.sin(phi) * Math.cos(th),
     r * Math.cos(phi),
     r * Math.sin(phi) * Math.sin(th));
  return out;
}

/* =================== tekstury WMTS =================== */
function proceduralTexture(color, kind){
  var c = document.createElement('canvas'); c.width=1024; c.height=512;
  var x = c.getContext('2d');
  x.fillStyle = color || '#888'; x.fillRect(0,0,1024,512);
  for (var i=0;i<2600;i++){
    var a = Math.random()*0.10;
    x.fillStyle = 'rgba('+(Math.random()<0.5?'0,0,0':'255,255,255')+','+a.toFixed(3)+')';
    x.beginPath(); x.arc(Math.random()*1024, Math.random()*512, Math.random()*9+1, 0, 7); x.fill();
  }
  if(kind==='moon'){
    for(i=0;i<90;i++){
      var cx=Math.random()*1024, cy=Math.random()*512, cr=Math.random()*14+3;
      x.strokeStyle='rgba(255,255,255,.10)'; x.lineWidth=1.4;
      x.beginPath(); x.arc(cx,cy,cr,0,7); x.stroke();
      x.fillStyle='rgba(0,0,0,.16)'; x.beginPath(); x.arc(cx+2,cy+2,cr*0.8,0,7); x.fill();
    }
  } else {
    for(i=0;i<26;i++){
      x.fillStyle='rgba(60,25,12,'+(0.05+Math.random()*0.1).toFixed(3)+')';
      x.beginPath(); x.ellipse(Math.random()*1024, Math.random()*380, 30+Math.random()*90, 15+Math.random()*40, 0, 0, 7); x.fill();
    }
  }
  return new THREE.CanvasTexture(c);
}
function loadImg(url, timeoutMs){
  return new Promise(function(res, rej){
    var im = new Image(); im.crossOrigin='anonymous';
    var to = setTimeout(function(){ rej(new Error('timeout')); }, timeoutMs||14000);
    im.onload = function(){ clearTimeout(to); res(im); };
    im.onerror = function(){ clearTimeout(to); rej(new Error('err')); };
    im.src = url;
  });
}
async function stitchLevel(base, ext, L, fillColor){
  var cols = Math.pow(2, L+1), rows = Math.pow(2, L);
  var c = document.createElement('canvas'); c.width = cols*256; c.height = rows*256;
  var x = c.getContext('2d');
  x.fillStyle = fillColor || '#666'; x.fillRect(0,0,c.width,c.height);
  var jobs = [], ok = 0;
  for (var row=0; row<rows; row++){
    for (var col=0; col<cols; col++){
      (function(row,col){
        jobs.push(loadImg(base + L + '/' + row + '/' + col + ext, 9000).then(function(im){
          x.drawImage(im, col*256, row*256); ok++;
        }).catch(function(){ /* brak kafla — zostaje tło */ }));
      })(row, col);
    }
  }
  await Promise.all(jobs);
  c._okRatio = ok / jobs.length;
  return c;
}
function showLoading(txt){ $('statusTxt').textContent = txt; $('status').style.display = 'flex'; }
function hideLoading(){ $('status').style.display = 'none'; }

function layersFor(p, kind){
  return (kind==='heat' && p.heatLayers && p.heatLayers.length) ? p.heatLayers : p.tileLayers;
}
async function buildLevel(key, L, kind){
  if(texCache[key][kind][L]) return texCache[key][kind][L];
  var p = PLANETS[key];
  for(var li=0; li<layersFor(p, kind).length; li++){
    try{
      var layer = layersFor(p, kind)[li];
      var c = await stitchLevel(trekUrl(layer.path), layer.e || layer.ext || '.jpg', L,
        kind==='heat' ? '#808080' : p.fallbackColor);
      if(c._okRatio > 0.5){
        if(kind!=='heat') globeCanvas[key] = { c:c, L:L };   // baza podłoży dla wycinków
        var tex = new THREE.CanvasTexture(c);
        tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
        /* RepeatWrapping: brak smużenia na szwie przy obrocie */
        tex.wrapS = THREE.RepeatWrapping;
        texCache[key][kind][L] = tex;
        return tex;
      }
    }catch(e){ /* warstwa martwa — następna */ }
  }
  return null;
}
function applyNow(t){
  if(flatMode) return;
  if(region.tex && region.key) return;   // aktywny ostry wycinek
  if(region.tex && !region.key){ region.tex.dispose(); region.tex = null; }
  globe.material.map = t; globe.material.bumpMap = t;
  globe.material.needsUpdate = true;
}
async function loadTextures(key){
  var kind = texKind;
  showLoading('tekstura: ' + PLANETS[key].label + '…');
  var t = await buildLevel(key, 2, kind);
  if(t && planetKey===key && kind===texKind){ hdTex[key][kind] = t; appliedL[key]=2; applyNow(t); }
  if(!t){ t = await buildLevel(key, 1, kind);
    if(t && planetKey===key && kind===texKind){ hdTex[key][kind] = t; appliedL[key]=1; applyNow(t); } }
  if(t){ t = await buildLevel(key, 3, kind);
    if(t && planetKey===key && kind===texKind){ hdTex[key][kind] = t; appliedL[key]=3; applyNow(t); } }
  hideLoading();
}

/* ====== progresywny LOD: ostre kafle widocznego obszaru przy zbliżeniu ====== */
function setGlobeTex(t){
  if(flatMode || !t) return;
  globe.material.map = t; globe.material.bumpMap = t;
  globe.material.bumpScale = reliefOn? 0.012 : 0;
  globe.material.needsUpdate = true;
}
function latLonFromVec(v){
  var r = v.length() || 1;
  var lat = 90 - Math.acos(Math.max(-1, Math.min(1, v.y/r))) * 180/Math.PI;
  var lon = Math.atan2(v.z, -v.x) * 180/Math.PI - 180;
  while(lon < -180) lon += 360;
  while(lon > 180) lon -= 360;
  return { lat:lat, lon:lon };
}
var region = { tex:null, key:'', pending:'', lastFail:'', busy:false, fails:0, seq:0 };
var lastRegionT = -1;
var HALF_BUCKETS = [1.2, 2, 3.2, 5, 8, 12, 18, 26, 40];
function quantKey(w){
  var hb = HALF_BUCKETS[HALF_BUCKETS.length-1];
  for(var i=0; i<HALF_BUCKETS.length; i++){ if(w.half <= HALF_BUCKETS[i]+0.001){ hb = HALF_BUCKETS[i]; break; } }
  var step = Math.max(0.3, hb*0.25);
  return w.kind + '|' + hb + '|' + (Math.round(w.lat/step)*step).toFixed(2) + '|' + (Math.round(w.lon/step)*step).toFixed(2);
}
async function buildRegionTex(w, cb){
  var p = PLANETS[planetKey];
  var layers = layersFor(p, w.kind);
  var lat0 = Math.max(-89, w.lat - w.half), lat1 = Math.min(89, w.lat + w.half);
  var hLon = Math.min(180, w.half / Math.max(0.3, Math.cos(w.lat*Math.PI/180)));
  var lonC = hLon < 180 ? Math.max(-180+hLon, Math.min(180-hLon, w.lon)) : w.lon;
  var lon0 = lonC - hLon, lon1 = lonC + hLon;
  var dLon = lon1 - lon0, dLat = lat1 - lat0;
  var L = 3;
  for(var l = Math.min(8, w.maxL || 8); l >= 3; l--){
    var nT  = Math.ceil(dLon/360 * Math.pow(2,l+1)) * Math.ceil(dLat/180 * Math.pow(2,l));
    var wpx = Math.round(dLon/360 * Math.pow(2,l+1) * 256);
    if(nT <= 200 && wpx <= 2800){ L = l; break; }
  }
  var colsT = Math.pow(2, L+1), rowsT = Math.pow(2, L);
  var W = Math.max(64, Math.round(dLon/360 * colsT * 256));
  var H = Math.max(64, Math.round(dLat/180 * rowsT * 256));
  var tex = null;
  for(var li=0; li<layers.length && !tex; li++){
    var layer = layers[li];
    var c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d');
    var g = globeCanvas[p.key];
    if(g && g.c){
      try{ x.drawImage(g.c, (lon0+180)/360*g.c.width, (90-lat1)/180*g.c.height,
        dLon/360*g.c.width, dLat/180*g.c.height, 0, 0, W, H); }catch(e){}
    } else { x.fillStyle = (w.kind==='heat') ? '#808080' : (p.fallbackColor || '#777'); x.fillRect(0,0,W,H); }
    var c0 = Math.floor((lon0+180)/360*colsT), c1 = Math.ceil((lon1+180)/360*colsT) - 1;
    var r0 = Math.floor((90-lat1)/180*rowsT), r1 = Math.ceil((90-lat0)/180*rowsT) - 1;
    var jobs = [], ok = 0;
    for(var row=r0; row<=r1; row++){
      for(var col=c0; col<=c1; col++){
        if(row < 0 || row >= rowsT) continue;
        (function(row, col){
          var xp = (col/colsT*360 - 180 - lon0)/dLon * W;
          var yp = (lat1 - (90 - row/rowsT*180))/dLat * H;
          var tw = 360/colsT/dLon*W + 1, th = 180/rowsT/dLat*H + 1;
          var colM = ((col % colsT) + colsT) % colsT;
          jobs.push(loadImg(trekUrl(layer.path) + L + '/' + row + '/' + colM + (layer.e || layer.ext || '.jpg'), 11000)
            .then(function(im){ x.drawImage(im, xp, yp, tw, th); ok++; })
            .catch(function(){}));
        })(row, col);
      }
    }
    await Promise.all(jobs);
    if(jobs.length && ok/jobs.length >= 0.35){
      tex = new THREE.CanvasTexture(c);
      tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
      /* RepeatWrapping — krawędź wycinka powtarza się zamiast rozciągać się na horyzoncie */
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.minFilter = THREE.LinearFilter; tex.generateMipmaps = false;
      tex.offset.set(-(lon0+180)/dLon, -(lat0+90)/dLat);
      tex.repeat.set(360/dLon, 180/dLat);
      tex.needsUpdate = true;
    }
  }
  cb(tex, !!tex);
}
function updateRegion(camDist){
  if(clock.elapsedTime - lastRegionT < 0.3) return;
  lastRegionT = clock.elapsedTime;
  var want;
  if(camDist >= 1.55){
    if(region.tex && hdTex[planetKey][texKind]){ region.tex.dispose(); region.tex = null; }
    region.key = '';
    setGlobeTex(hdTex[planetKey][texKind]);
    return;
  }
  /* wycinek zawsze pokrywa widoczny czap globusa (bez smużenia przy obrocie) */
  var vis = Math.acos(Math.max(-1, Math.min(1, 1/camDist))) * 180/Math.PI;
  var v = latLonFromVec(camera.position);
  want = { lat:v.lat, lon:v.lon, half:Math.max(1.2, Math.min(40, vis*1.12 + 2)), maxL:8, kind:texKind };
  var key = quantKey(want);
  if(region.busy) return;
  if(key === region.key && region.tex) return;
  if(key === region.lastFail && region.fails >= 2) return;
  region.busy = true; region.pending = key;
  var seq = ++region.seq;
  showLoading('dociągam szczegóły…');
  buildRegionTex(want, function(tex){
    region.busy = false;
    if(seq !== region.seq){ if(tex) tex.dispose(); return; }
    hideLoading();
    if(tex){
      if(region.tex) region.tex.dispose();
      region.tex = tex; region.key = region.pending; region.fails = 0; region.lastFail = '';
      setGlobeTex(tex);
    } else {
      region.fails++; region.lastFail = region.pending;
    }
  });
}

/* ====== niebo: NASA SVS Deep Star Maps 2020 (4K) ====== */
var _skyLUT = null;
function halfToFloat(h){
  var s = (h & 0x8000) >> 15, e = (h & 0x7c00) >> 10, m = h & 0x3ff, f;
  if(e === 0) f = m * Math.pow(2, -24);
  else if(e === 31) f = m ? NaN : Infinity;
  else f = (1 + m/1024) * Math.pow(2, e - 15);
  return s ? -f : f;
}
function skyLUT(){
  if(_skyLUT) return _skyLUT;
  var LUT = new Uint16Array(65536);
  for(var p=0; p<65536; p++){
    var f = halfToFloat(p);
    if(!isFinite(f) || f <= 0){ LUT[p] = p; continue; }
    var g = Math.pow(Math.min(f, 64), 1/2.2) * 1.10;   // linear -> wyświetlanie
    LUT[p] = THREE.DataUtils.toHalfFloat(g);
  }
  _skyLUT = LUT; return LUT;
}
function gammaSky(tex){
  var img = tex.image;
  if(!img || !img.data) return;
  var data = img.data, n = img.width * img.height, ch = data.length / n;
  if((ch !== 3 && ch !== 4) || !(data instanceof Uint16Array)) return;
  var LUT = skyLUT();
  for(var i=0; i<n; i++){
    var b = i*ch;
    data[b] = LUT[data[b]]; data[b+1] = LUT[data[b+1]]; data[b+2] = LUT[data[b+2]];
  }
  tex.needsUpdate = true;
}
function equirectToBackground(tex, size){
  var rt = new THREE.WebGLCubeRenderTarget(size || 1024, { type: THREE.HalfFloatType });
  rt.fromEquirectangularTexture(renderer, tex);
  scene.background = rt.texture;
}
function initSky(){
  if(typeof THREE.EXRLoader === 'undefined' || typeof fflate === 'undefined') return initSkyJPG();
  showLoading('niebo: skybox.exr (NASA SVS)…');
  var l = new THREE.EXRLoader();
  l.load('assets/skybox.exr', function(tex){
    try{ gammaSky(tex); }catch(e){}
    var h = (tex.image && tex.image.height) || 2048;
    equirectToBackground(tex, Math.min(2048, Math.floor(h/2)));
    tex.dispose(); skyReady = true; hideLoading();
  }, undefined, function(){
    console.warn('skybox.exr niedostępny — fallback na skybox.jpg');
    initSkyJPG();
  });
}
function initSkyJPG(){
  showLoading('niebo: skybox.jpg…');
  var l = new THREE.TextureLoader(); l.setCrossOrigin('anonymous');
  l.load('assets/skybox.jpg', function(tex){
    equirectToBackground(tex, 1024);
    tex.dispose(); skyReady = true; hideLoading();
  }, undefined, function(){
    console.warn('skybox.jpg niedostępny — gwiazdy proceduralne');
    skyMesh = makeSkyboxFallback(); scene.add(skyMesh); hideLoading();
  });
}
/* zapasowe tło: gwiazdy + pas Drogi Mlecznej (rysunek proceduralny) */
function drawGalaxyFallback(x, W, H){
  x.globalCompositeOperation = 'lighter';
  for(var i=0;i<170;i++){
    var fx = (i+0.5)/170*W;
    var fy = H*0.5 + H*0.24*Math.sin(fx/W*Math.PI*2 + 0.9);
    var rg = x.createRadialGradient(fx,fy,0,fx,fy,H*0.11);
    rg.addColorStop(0,'rgba(215,222,255,.05)'); rg.addColorStop(1,'rgba(0,0,0,0)');
    x.fillStyle = rg; x.beginPath(); x.arc(fx,fy,H*0.11,0,7); x.fill();
  }
  x.globalCompositeOperation = 'source-over';
}
function makeSkyboxFallback(){
  var W = 2048, H = 1024;
  var c = document.createElement('canvas'); c.width = W; c.height = H;
  var x = c.getContext('2d');
  var g = x.createLinearGradient(0,0,0,H);
  g.addColorStop(0,'#04050a'); g.addColorStop(0.5,'#080a12'); g.addColorStop(1,'#04050a');
  x.fillStyle = g; x.fillRect(0,0,W,H);
  var neb = [[330,290,270,'rgba(92,64,140,.10)'],[1520,640,300,'rgba(150,84,40,.09)'],
             [1020,210,230,'rgba(44,84,150,.08)'],[640,780,250,'rgba(120,52,92,.08)']];
  for(var i=0;i<neb.length;i++){
    var n = neb[i], rg = x.createRadialGradient(n[0],n[1],0,n[0],n[1],n[2]);
    rg.addColorStop(0,n[3]); rg.addColorStop(1,'rgba(0,0,0,0)');
    x.fillStyle = rg; x.beginPath(); x.arc(n[0],n[1],n[2],0,7); x.fill();
  }
  for(i=0;i<2400;i++){
    var sx = Math.random()*W, sy = Math.random()*H;
    var big = Math.random() > 0.93;
    var r = big ? Math.random()*1.5+1.1 : Math.random()*0.9+0.25;
    var a = Math.random()*0.7+0.28;
    var tR = Math.random();
    var col = tR<0.7 ? '218,226,255' : (tR<0.88 ? '255,242,222' : '255,206,164');
    if(big){
      var sg = x.createRadialGradient(sx,sy,0,sx,sy,r*5.5);
      sg.addColorStop(0,'rgba('+col+',.4)'); sg.addColorStop(1,'rgba(0,0,0,0)');
      x.fillStyle = sg; x.beginPath(); x.arc(sx,sy,r*5.5,0,7); x.fill();
    }
    x.fillStyle = 'rgba('+col+','+a.toFixed(2)+')';
    x.beginPath(); x.arc(sx,sy,r,0,7); x.fill();
  }
  var tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  var im = new Image(); im.crossOrigin = 'anonymous';
  im.onload = function(){
    try{
      x.globalCompositeOperation = 'lighter'; x.globalAlpha = 0.9;
      var strips = 96, sw = im.width/strips, dw = W/strips + 1, bh = H*0.62;
      for(var s2=0; s2<strips; s2++){
        var cx = (s2+0.5)*dw;
        var cy = H*0.5 + H*0.24*Math.sin(cx/W*Math.PI*2 + 0.9);
        x.drawImage(im, s2*sw, 0, sw+1, im.height, cx-dw/2, cy-bh/2, dw, bh);
      }
      x.globalAlpha = 1; x.globalCompositeOperation = 'source-over';
    }catch(e){ drawGalaxyFallback(x,W,H); }
    tex.needsUpdate = true;
  };
  im.onerror = function(){ drawGalaxyFallback(x,W,H); tex.needsUpdate = true; };
  im.src = 'https://images-assets.nasa.gov/image/PIA17996/PIA17996~large.jpg';
  var m = new THREE.Mesh(new THREE.SphereGeometry(60, 48, 32),
    new THREE.MeshBasicMaterial({map:tex, side:THREE.BackSide, depthWrite:false}));
  m.rotation.x = 0.52; m.rotation.z = 0.18;
  m.frustumCulled = false;
  return m;
}

/* =================== heightmapa (DEM) =================== */
async function loadHeights(key){
  var p = PLANETS[key];
  var bases = p.demLayers.concat(p.heightFallback ? [p.heightFallback] : []);
  var exts = ['.png', '.jpg'];
  for(var bi=0; bi<bases.length; bi++){
    for(var ei=0; ei<exts.length; ei++){
      try{
        var c = await stitchLevel(trekUrl(bases[bi]), exts[ei], 2, '#808080');
        if(c._okRatio > 0.5){
          var W = c.width, H = c.height;
          var d = c.getContext('2d').getImageData(0,0,W,H).data;
          var data = new Float32Array(W*H);
          for(var i=0;i<W*H;i++) data[i] = (d[i*4] + d[i*4+1] + d[i*4+2]) / 765;
          heightData[key] = { data:data, W:W, H:H };
          return true;
        }
      }catch(e){ /* następny kandydat */ }
    }
  }
  return false;
}
function ensureHeights(key){
  if(!heightCache[key]) heightCache[key] = loadHeights(key);
  return heightCache[key];
}
function terrainR(lat, lon){
  if(!reliefOn) return 1;
  var hd = heightData[planetKey];
  if(!hd) return 1;
  var u = (lon+180)/360, v = 1-(lat+90)/180;
  var xi = Math.max(0, Math.min(hd.W-1, Math.round(u*(hd.W-1))));
  var yi = Math.max(0, Math.min(hd.H-1, Math.round(v*(hd.H-1))));
  return 1 + (hd.data[yi*hd.W+xi] - 0.5) * 2 * PLANETS[planetKey].heightScale;
}
function markR(lat, lon){ return terrainR(lat, lon) + 0.004; }
function displaceGeometry(hd, scale){
  var g = baseGeom.clone();
  var pos = g.attributes.position;
  for(var i=0;i<pos.count;i++){
    var x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    var len = Math.sqrt(x*x + y*y + z*z) || 1;
    var nx = x/len, ny = y/len, nz = z/len;
    var lat = 90 - Math.acos(Math.max(-1, Math.min(1, ny))) * 180/Math.PI;
    var lon = Math.atan2(nz, -nx) * 180/Math.PI - 180;
    var u = (lon+180)/360, v = 1-(lat+90)/180;
    var xi = Math.max(0, Math.min(hd.W-1, Math.round(u*(hd.W-1))));
    var yi = Math.max(0, Math.min(hd.H-1, Math.round(v*(hd.H-1))));
    var r = 1 + (hd.data[yi*hd.W+xi] - 0.5) * 2 * scale;
    pos.setXYZ(i, nx*r, ny*r, nz*r);
  }
  pos.needsUpdate = true;
  g.computeVertexNormals();
  return g;
}
function applyRelief(){
  var key = planetKey, p = PLANETS[key];
  controls.minDistance = reliefOn ? 1.10 : 1.02;
  if(reliefOn && heightData[key]){
    if(!reliefGeoms[key]) reliefGeoms[key] = displaceGeometry(heightData[key], p.heightScale);
    globe.geometry = reliefGeoms[key];
  } else {
    globe.geometry = baseGeom;
    if(reliefOn && !heightData[key]){
      ensureHeights(key).then(function(){ if(reliefOn && planetKey===key) applyRelief(); });
    }
  }
  rebuildOverlays();
}
function rebuildOverlays(){
  buildMarkers();
  updateActiveClasses();
  if(selected && traverseData){
    var wasPlayed = traverseData.played;
    drawRoute(traverseData.info);
    traverseData.played = wasPlayed;
  }
  updateRouteProgress();
}

/* =================== dane obiektów =================== */
function normalizeMars(rows){
  return rows.filter(function(r){ return r.latitude!=null; }).map(function(r){
    var m = META[r.slug]||{};
    return { slug:r.slug, name:r.name, entity:r.entity||'', type:r.type, outcome:r.outcome,
      lat:r.latitude, lon:r.longitude_east_180!=null? r.longitude_east_180 : r.longitude_east_360,
      desc:r.site_name||'', page:r.page,
      launch:m.l||null, arrival:m.a||null, end:m.e||null, plan:!!m.plan,
      cel:m.cel||null, st:m.st||null, ev:m.ev||null };
  });
}
function normalizeMoon(json){
  return json.sites.filter(function(r){ return r.latitude!=null; }).map(function(r){
    var m = META[r.slug]||{};
    return { slug:r.slug, name:r.name, entity:r.operator||'', type:r.type, outcome:r.outcome,
      lat:r.latitude, lon:r.longitude, year:r.year, arrived:r.arrived!==false, desc:r.site_name||'', page:r.url,
      launch:m.l||null, arrival:m.a||null, end:m.e||null, plan:!!m.plan || r.arrived===false,
      cel:m.cel||null, st:m.st||null, ev:m.ev||null };
  });
}
async function loadSites(p){
  var j = null;
  try{
    var r = await fetch(API + p.sitesFile, {cache:'no-cache'});
    if(r.ok) j = await r.json();
  }catch(e){ /* fallback lokalny */ }
  if(!j){
    try{
      var r2 = await fetch('assets/api/' + p.sitesFile);
      if(r2.ok) j = await r2.json();
    }catch(e){}
  }
  if(!j) throw new Error('brak danych obiektów');
  var list = (p.key==='mars') ? normalizeMars(j) : normalizeMoon(j);
  list.forEach(function(s){
    s.arrivalY = s.plan ? yearOf(s.arrival) : (yearOf(s.arrival) || (p.key==='moon' ? s.year : null) || null);
    s.endY = yearOf(s.end);
    if(s.endY==null && s.outcome==='operating') s.endY = null;
  });
  return list;
}

/* =================== statusy =================== */
var STATUS_COLORS = { active:'#57e389', ended:'#5d6b7a', planned:'#ffb020', info:'#8fa7b8', fail:'#ff5c57', future:'#39434d' };
function statusAt(s, Y){
  if(s.plan) return 'planned';
  if(s.arrivalY==null) return 'info';
  if(Y < s.arrivalY) return 'future';
  if(s.endY!=null && Y >= s.endY) return 'ended';
  return 'active';
}
function cssStatus(s, Y){
  var st = statusAt(s, Y);
  if(st === 'future') return STATUS_COLORS.future;
  if(s.outcome === 'failure' && st === 'ended') return STATUS_COLORS.fail;
  return STATUS_COLORS[st] || STATUS_COLORS.info;
}
function siteVisible(s){
  if(!fQ) return true;
  var q = fQ.toLowerCase();
  var hay = (s.name+' '+(s.entity||'')+' '+(TYPE_PL[s.type]||s.type||'')+' '+s.slug).toLowerCase();
  return hay.indexOf(q) >= 0;
}

/* =================== markery 3D (HTML) =================== */
/* biały duży kwadrat z mniejszym kwadratem w środku; hover: obrót 45°;
   aktywny: stałe powiększenie + skok o 180° co 500 ms */
function buildMarkers(){
  sites.forEach(function(s){ if(s.el){ setActiveRot(s.el, false); } });
  markerLayer.innerHTML = '';
  sites.forEach(function(s){
    var el = document.createElement('div');
    el.className = 'mk';
    el.innerHTML = '<span class="sqd"><span class="dot"></span></span><span class="lbl">'+esc(s.name)+'</span>';
    el.addEventListener('click', function(ev){ ev.stopPropagation(); select(s); });
    markerLayer.appendChild(el);
    s.el = el;
  });
}
function setActiveRot(el, on){
  if(on){
    if(rotMap[el.__rotId]) return;
    el.__deg = 0;
    el.style.setProperty('--rot','0deg');
    var e2 = el;
    rotMap[el.__rotId = el.__rotId || Math.random()] = setInterval(function(){
      e2.__deg = (e2.__deg + 180) % 360000;
      e2.style.setProperty('--rot', e2.__deg + 'deg');
    }, 500);
  } else if(el.__rotId && rotMap[el.__rotId]){
    clearInterval(rotMap[el.__rotId]); delete rotMap[el.__rotId];
    el.style.setProperty('--rot','0deg');
  }
}
function updateActiveClasses(){
  sites.forEach(function(s){
    if(!s.el) return;
    var on = (selected===s);
    s.el.classList.toggle('on', on);
    setActiveRot(s.el, on);
  });
}
var _mv = new THREE.Vector3(), _mn = new THREE.Vector3(), _pr = new THREE.Vector3();
function updateMarkers(){
  var camDist = camera.position.length();
  if(!isFinite(camDist) || camDist<=0) return;
  _mn.copy(camera.position).normalize();
  var horizon = 1/camDist;
  var w = window.innerWidth, h = window.innerHeight;
  for(var i=0;i<sites.length;i++){
    var s = sites[i];
    if(!s.el) continue;
    var st = statusAt(s, year);
    var vis = (st!=='future') && siteVisible(s);
    if(!vis){ if(s.el.style.display!=='none') s.el.style.display='none'; s.el.__vis=false; continue; }
    latLonInto(_mv, s.lat, s.lon, markR(s.lat, s.lon));
    var facing = _mn.dot(_mv)/(_mv.length()||1);
    if(facing < horizon - 0.005){ if(s.el.style.display!=='none') s.el.style.display='none'; s.el.__vis=false; continue; }
    _pr.copy(_mv).project(camera);
    if(_pr.z > 1){ if(s.el.style.display!=='none') s.el.style.display='none'; s.el.__vis=false; continue; }
    var x = (_pr.x*0.5+0.5)*w, y = (-_pr.y*0.5+0.5)*h;
    s.el.style.display = 'block';
    s.el.style.transform = 'translate('+x.toFixed(1)+'px,'+y.toFixed(1)+'px) translate(-50%,-50%)';
    var dpt = camera.position.distanceTo(_mv);
    s.el.style.zIndex = String(Math.max(1, Math.min(999, Math.round(1000 - dpt*100))));
    s.el.__sx = x; s.el.__sy = y; s.el.__vis = true;
  }
}

/* =================== trasy =================== */
function getTraverse(slug){
  if(!planet || !planet.traverses) return Promise.resolve(null);
  var file = (ALIAS && ALIAS[slug]) || slug;
  if(traverseCache[slug]!==undefined) return traverseCache[slug];
  traverseCache[slug] = fetch(API+'mars-traverses/'+file+'.json').then(function(r){
    return r.ok ? r.json() : null;
  }).catch(function(){
    return fetch('assets/api/traverses/'+file+'.json').then(function(r){
      return r.ok ? r.json() : null;
    }).catch(function(){ return null; });
  });
  return traverseCache[slug];
}
function clearRoute(){
  while(routeGroup.children.length) routeGroup.remove(routeGroup.children[0]);
  traverseData = null; headMarker.visible = false;
  if(routePlay){ routePlay = null; controls.enabled = true; }
  $('pRoute').style.display = 'none';
}
function drawRoute(t){
  clearRoute();
  var path = (t.path && t.path.lon && t.path.lon.length) ? t.path : t.pathLite;
  if(!path || !path.lon) return;
  var n = path.lon.length;
  var useSol = path.sol && path.sol.length===n;
  var epochMs = t.sol && t.sol.epochUnixS ? t.sol.epochUnixS*1000 : (t.landing && t.landing.utc ? Date.parse(t.landing.utc) : null);
  var msPerSol = t.sol && t.sol.solS ? t.sol.solS*1000 : 88775244;
  var pts = new Array(n);
  for(var i=0;i<n;i++) pts[i] = latLonToVec3(path.lat[i], path.lon[i], markR(path.lat[i], path.lon[i]));
  var geo = new THREE.BufferGeometry().setFromPoints(pts);
  var line = new THREE.Line(geo, new THREE.LineBasicMaterial({color:0xff9a3d}));
  routeGroup.add(line);
  traverseData = { line:line, pts:pts, n:n, sols:useSol?path.sol:null, epochMs:epochMs, msPerSol:msPerSol, info:t, played:false };
  updateRouteProgress();
}
function startRoutePlay(){
  if(!traverseData || !traverseData.n) return;
  routePlay = { i:0, n:traverseData.n, speed: Math.max(3, traverseData.n/36), intro:true };
  traverseData.line.geometry.setDrawRange(0, 1);
  headMarker.visible = true;
  camAnim = null;
  controls.enabled = false;
  $('pRoute').style.display = 'block';
  $('prFill').style.width = '0%'; $('prTxt').textContent = 'TRASA · 0%';
}
function stepRoutePlay(dt){
  var rp = routePlay, td = traverseData;
  if(!rp || !td) return;
  rp.i = Math.min(rp.n-1, rp.i + rp.speed*dt);
  var i0 = Math.floor(rp.i), fr = rp.i - i0, i1 = Math.min(rp.n-1, i0+1);
  var p = td.pts[i0].clone().lerp(td.pts[i1], fr);
  var desired = p.clone().multiplyScalar(1.052);   // punkt + wysokość nad powierzchnią
  camera.up.copy(p).normalize();
  if(rp.intro){
    camera.position.lerp(desired, 0.075);
    controls.target.lerp(p, 0.09);
    if(camera.position.distanceTo(desired) < 0.045) rp.intro = false;
  } else {
    camera.position.lerp(desired, 0.16);
    controls.target.lerp(p, 0.22);
  }
  headMarker.position.copy(p);
  td.line.geometry.setDrawRange(0, i0+1);
  var pct = Math.round(rp.i/(rp.n-1)*100);
  $('prFill').style.width = pct+'%'; $('prTxt').textContent = 'TRASA · '+pct+'%';
  if(rp.i >= rp.n-1){
    routePlay = null; td.played = true;
    controls.enabled = true;
    $('prTxt').textContent = 'TRASA · KONIEC';
    $('prFill').style.width = '100%';
  }
}
function stopRoutePlay(){
  routePlay = null;
  controls.enabled = true;
  camera.up.set(0,1,0);
  controls.target.set(0,0,0);
}
function updateRouteProgress(){
  if(!traverseData || !selected || routePlay) return;
  var Y = year, td = traverseData;
  if(td.played){ td.line.geometry.setDrawRange(0, td.n); headMarker.visible = true; headMarker.position.copy(td.pts[td.n-1]); return; }
  if(td.sols && td.epochMs!=null){
    var yMs = (Y - 1970) * 31557600000;
    var lo=0, hi=td.n-1, count;
    if(td.epochMs + td.sols[0]*td.msPerSol > yMs){ count = 0; }
    else {
      while(lo<hi){
        var mid = (lo+hi+1)>>1;
        if(td.epochMs + td.sols[mid]*td.msPerSol <= yMs) lo = mid; else hi = mid-1;
      }
      count = lo+1;
    }
  } else {
    var a = selected.arrivalY || (selected.year||2026), b = selected.endY || new Date().getFullYear();
    var f = Math.max(0, Math.min(1, (Y - a) / Math.max(1,(b - a))));
    count = Math.max(1, Math.round(f * td.n));
  }
  td.line.geometry.setDrawRange(0, count);
  if(count>0){
    headMarker.position.copy(td.pts[count-1]);
    headMarker.visible = !!selected && statusAt(selected, Y)!=='future';
  } else headMarker.visible = false;
}

/* =================== kamera =================== */
function focusOn(s, dist){
  var p = latLonToVec3(s.lat, s.lon, 1).normalize().multiplyScalar(dist||1.62);
  camAnim = { to:p };
}
function homeView(){
  camAnim = { to:new THREE.Vector3(0, 0.9, 2.7) };
}
function setAutoRotate(){
  controls.autoRotate = autoRotateOn && !selected && !playing;
}

/* =================== dane popupów: zdumpowane strony NASA (assets/dumps) =================== */
var dumpCache = {};
function getDump(s){
  var map = DUMPS && DUMPS[planetKey];
  var f = map && map[s.slug];
  if(!f) return Promise.resolve(null);
  if(dumpCache[f]) return dumpCache[f];
  dumpCache[f] = fetch('assets/dumps/'+encodeURIComponent(f)).then(function(r){
    return r.ok ? r.json() : null;
  }).catch(function(){ return null; });
  return dumpCache[f];
}
function dumpTimeline(d){
  if(!d || !d.timeline || !d.timeline.length) return [];
  return d.timeline.map(function(x){ return { d:x.date||'', t:x.title||'' }; })
    .filter(function(x){ return x.t; });
}
function vehDates(d){
  return (d && d.vehicle && d.vehicle.dates) ? d.vehicle.dates : null;
}
function dumpStart(d, s){
  var dt = vehDates(d);
  if(dt && dt.launch && dt.launch.date) return dt.launch.date;
  if(s.launch) return s.launch;
  if(d && d.vehicle && d.vehicle.rovers && d.vehicle.rovers[s.slug] && d.vehicle.rovers[s.slug].landing)
    return d.vehicle.rovers[s.slug].landing.date;
  return null;
}
function dumpEnd(d, s){
  if(d && d.vehicle && d.vehicle.rovers && d.vehicle.rovers[s.slug] && d.vehicle.rovers[s.slug].mission_end)
    return d.vehicle.rovers[s.slug].mission_end.date;
  var dt = vehDates(d);
  if(dt){
    var e = dt.end_of_operations || dt.mission_end || dt.disposal || null;
    if(e && e.date) return e.date;
  }
  return s.end || null;
}
function dumpType(d, s){
  if(d && d.vehicle && d.vehicle.rovers && d.vehicle.rovers[s.slug]) return TYPE_PL[s.type] || 'łazik';
  if(d && d.vehicle && d.vehicle.type){
    var t = d.vehicle.type;
    return t.name || t.page_label || t.category || (TYPE_PL[s.type]||s.type||'—');
  }
  return TYPE_PL[s.type] || s.type || '—';
}
function dumpWho(d, s){
  if(d && d.vehicle && d.vehicle.agency){
    var a = String(d.vehicle.agency);
    return { short: a.split(' / ')[0].trim(), full: a };
  }
  return { short: s.entity || '—', full: s.entity || '' };
}
function dumpSuccess(d, s){
  if(d && d.vehicle && d.vehicle.status){
    var st = String(d.vehicle.status).toLowerCase();
    if(st.indexOf('fail')>=0 || st.indexOf('lost')>=0 || st.indexOf('crash')>=0) return 'bad';
    if(st.indexOf('completed')>=0 || st.indexOf('success')>=0) return 'ok';
  }
  if(s.outcome==='failure') return 'bad';
  if(s.outcome==='partial') return 'part';
  if(s.outcome==='success' || s.outcome==='operating' || s.outcome==='ended') return 'ok';
  return null;
}

/* =================== popup obiektu (panel po prawej) =================== */
function setTab(id, val, cls){
  var el = $(id);
  el.innerHTML = cls ? '<span class="'+cls+'">'+esc(val)+'</span>' : esc(val);
}
function openPopup(s){
  var t = TYPE_PL[s.type]||s.type||'';
  $('pId').textContent = 'MSN-' + String(sites.indexOf(s)+1).padStart(3,'0');
  $('pType').innerHTML = iconFor(s.type) + ' ' + esc(String(t).toUpperCase()) +
    (s.entity? ' · '+esc(String(s.entity).toUpperCase()) : '');
  var nameEl = $('pName');
  nameEl.textContent = s.name;
  nameEl.style.color = cssStatus(s, year);
  $('pImg').innerHTML = '<div class="phImg">PODAWANIE DANYCH…</div>';
  setTab('tStart','—'); setTab('tEnd','—'); setTab('tType','—'); setTab('tWho','—'); setTab('tSucc','—');
  $('pDesc').textContent = '';
  $('pLink').style.display = 'none';
  $('pRoute').style.display = 'none';
  popupEl.style.display = 'flex';
  popupEl.scrollTop = 0;

  getDump(s).then(function(d){
    if(selected!==s) return;
    /* zdjęcie — wyłącznie z danych zdumpowanych */
    var img = d && d.media && (d.media.hero_image || (d.media.images && d.media.images[0]));
    $('pImg').innerHTML = (img && img.url) ? '<img src="'+esc(img.url)+'" alt="">' : '';
    /* mini tabelka */
    var who = dumpWho(d, s);
    setTab('tStart', fmtDate(dumpStart(d, s)));
    setTab('tEnd', fmtDate(dumpEnd(d, s)));
    setTab('tType', dumpType(d, s));
    var tw = $('tWho'); tw.textContent = who.short; tw.title = who.full || '';
    var succ = dumpSuccess(d, s);
    setTab('tSucc', succ==='bad'?'NIE':(succ==='part'?'CZĘŚCIOWO':(succ==='ok'?'TAK':'—')),
      succ==='bad'?'bad':(succ==='part'?'part':(succ==='ok'?'ok':null)));
    /* opis + link */
    var lead = d && d.article && d.article.lead ? firstSentences(d.article.lead, 2) : '';
    $('pDesc').textContent = lead || s.cel || s.desc || '';
    var link = (d && d.source && (d.source.canonical_url || d.source.url)) || s.page || '';
    if(link){ $('pLink').href = link; $('pLink').style.display = 'flex'; }
    /* historia pojazdu — oś wydarzeń po lewej */
    var hist = dumpTimeline(d);
    if(!hist.length && HISTORY && HISTORY[s.slug]) hist = HISTORY[s.slug];
    showVhist(s.name, hist);
  });
}
function closePopup(){
  popupEl.style.display = 'none';
  frameEl.style.display = 'none';
  hideVhist();
  stopRoutePlay();
  clearRoute();
  selected = null;
  updateActiveClasses();
  controls.enableRotate = true;
  document.body.classList.remove('locked');
  if(camera.position.length() < 1.35)
    camAnim = { to: camera.position.clone().normalize().multiplyScalar(1.62) };
  setAutoRotate();
}

/* =================== oś wydarzeń pojazdu (lewa krawędź) =================== */
var vhEvents=[], vhI=0;
function showVhist(name, list){
  if(!list || !list.length){ hideVhist(); return; }
  vhEvents = list; vhI = 0;
  document.body.classList.add('hist-on');
  $('vhist').style.display = 'flex';
  $('vhName').textContent = name;
  var box = $('vhList'); box.innerHTML = '';
  list.forEach(function(ev, i){
    var el = document.createElement('div');
    el.className = 'vh';
    el.innerHTML = '<span class="vhd">'+esc(fmtDate(ev.d))+'</span><span class="vht">'+esc(ev.t)+'</span>';
    box.appendChild(el);
  });
  vhHighlight();
}
function vhHighlight(){
  var items = $('vhList').children;
  for(var i=0;i<items.length;i++) items[i].classList.toggle('on', i===vhI);
  $('vhIdx').textContent = (vhI+1)+'/'+vhEvents.length;
  if(items[vhI] && items[vhI].scrollIntoView) items[vhI].scrollIntoView({block:'nearest'});
}
function hideVhist(){
  vhEvents = [];
  $('vhist').style.display = 'none';
  document.body.classList.remove('hist-on');
}
/* oś nie jest stopowana — nowy wpis co 5 sekund, w kółko */
setInterval(function(){
  if(vhEvents.length < 2) return;
  vhI = (vhI+1) % vhEvents.length;
  vhHighlight();
}, 5000);

/* =================== ramka wokół punktu i opisu =================== */
function updateFrame(){
  if(!selected || popupEl.style.display==='none' || !selected.el || !selected.el.__vis){
    if(frameEl.style.display!=='none') frameEl.style.display='none';
    return;
  }
  var x = selected.el.__sx, y = selected.el.__sy;
  var lbl = selected.el.querySelector('.lbl');
  var lw = lbl ? lbl.offsetWidth : 0;
  var left = x-15, right = x+15+(lw? 25+lw : 0), top = y-15, bottom = y+15;
  var m = 26;
  frameEl.style.display = 'block';
  frameEl.style.left = (left-m)+'px';
  frameEl.style.top = (top-m)+'px';
  frameEl.style.width = (right-left+2*m)+'px';
  frameEl.style.height = (bottom-top+2*m)+'px';
}

/* =================== wybór obiektu =================== */
function select(s, opts){
  if(playing && !(opts && opts.demo)){ playing=false; setPlayIcon(); }
  selected = s;
  setAutoRotate();
  controls.enableRotate = false;
  document.body.classList.add('locked');
  focusOn(s, 1.62);
  openPopup(s);
  updateActiveClasses();
  clearRoute();
  if(planet.traverses && (s.type==='rover' || s.type==='helicopter')){
    getTraverse(s.slug).then(function(t){
      if(!t || selected!==s) return;
      drawRoute(t);
      startRoutePlay();   // przybliż i odtwórz ruch pojazdu
    });
  }
}

/* =================== oś czasu (pasek na górze, nieliniowa) =================== */
function buildEvents(){
  events = [];
  sites.forEach(function(s){
    if(s.arrivalY==null) return;
    events.push({ y:s.arrivalY, s:s });
  });
  events.sort(function(a,b){ return a.y-b.y; });
}
/* pozycje: równa odległość między zdarzeniami (oś nieliniowa) */
function buildTicks(){
  var box = $('tlTicks'); box.innerHTML = '';
  var n = events.length;
  events.forEach(function(ev, i){
    var t = document.createElement('div');
    t.className = 'tickline';
    t.style.left = (n>1 ? i/(n-1)*100 : 50) + '%';
    if(ev.s.plan) t.classList.add('plan');
    else if(ev.s.outcome==='failure' || ev.s.endY!=null) t.classList.add('aband');  // porzucone
    t.addEventListener('click', function(e){
      e.stopPropagation();
      playing = false; setPlayIcon();
      demoSlide(i);
    });
    box.appendChild(t);
    ev.el = t;
  });
}
function posToYear(p){
  var n = events.length;
  if(n===0) return planet ? planet.maxYear : 2026;
  if(n===1 || p<=0) return events[0].y;
  if(p>=n-1) return events[n-1].y;
  var i = Math.floor(p), f = p - i;
  return events[i].y + (events[i+1].y - events[i].y) * f;
}
function paintTime(){
  var n = events.length;
  var f = n>1 ? tPos/(n-1) : 0;
  $('tlFill').style.width = (f*100)+'%';
  $('tlHead').style.left = (f*100)+'%';
  $('tlDate').textContent = fmtISO(posToYear(tPos));
}
function setPos(p, mode){
  var n = events.length;
  tPos = Math.max(0, Math.min(n-1, p));
  var prev = year;
  year = posToYear(tPos);
  paintTime();
  if(Math.round(year) !== Math.round(prev)) updateRouteProgress();
  if(mode==='user'){
    var idx = Math.round(tPos);
    if(idx!==lastScrubIdx && events[idx]){ lastScrubIdx = idx; select(events[idx].s); }
  }
}
function easeIO(t){ return t<0.5 ? 4*t*t*t : 1 - Math.pow(-2*t+2, 3)/2; }
/* płynne przesunięcie osi do zdarzenia i (od razu do kolejnej rzeczy) */
function demoSlide(i){
  if(!events.length || slide) return;
  i = Math.max(0, Math.min(events.length-1, i));
  lastScrubIdx = -1;
  slide = { from:tPos, to:i, t:0 };
}
function arriveAt(i){
  if(i>=0 && i<events.length) select(events[i].s, {demo:true});
  else { playing=false; setPlayIcon(); }
}
function nextEvent(){
  var n = events.length;
  if(!n) return;
  if(tPos >= n-1){ demoSlide(0); return; }   // po ostatnim — od początku
  demoSlide(Math.floor(tPos + 1e-6) + 1);
}
function setPlayIcon(){
  $('play').innerHTML = playing? '<i class="ph-fill ph-pause"></i>' : '<i class="ph-fill ph-play"></i>';
  $('btNext').classList.toggle('idle', !playing && !slide);
}
function seekToSite(s){
  playing = false; slide = null; setPlayIcon();
  for(var i=0;i<events.length;i++){
    if(events[i].s===s){
      tPos = i; lastScrubIdx = i;
      year = posToYear(tPos);
      paintTime(); updateRouteProgress();
      break;
    }
  }
  select(s);
}
(function wireTimeline(){
  $('play').addEventListener('click', function(){
    if(playing){ playing = false; setPlayIcon(); setAutoRotate(); }
    else { playing = true; dwellT = Math.min(dwellT||0.6, 0.6); if(!slide && events.length) nextEvent(); setPlayIcon(); setAutoRotate(); }
  });
  $('btNext').addEventListener('click', function(){
    playing = false; setPlayIcon();
    var n = events.length;
    if(!n) return;
    nextEvent();
  });
  var track = $('tlTrack'), scrubbing = false;
  function scrub(e){
    var r = track.getBoundingClientRect();
    var f = Math.max(0, Math.min(1, (e.clientX - r.left)/r.width));
    setPos(f * Math.max(0, events.length-1), 'user');
  }
  track.addEventListener('pointerdown', function(e){
    scrubbing = true;
    playing = false; slide = null; setPlayIcon();
    lastScrubIdx = -1;
    track.setPointerCapture(e.pointerId);
    scrub(e);
    e.preventDefault();
  });
  track.addEventListener('pointermove', function(e){ if(scrubbing) scrub(e); });
  track.addEventListener('pointerup', function(){ scrubbing = false; lastScrubIdx = Math.round(tPos); });
  track.addEventListener('pointercancel', function(){ scrubbing = false; lastScrubIdx = Math.round(tPos); });
})();

/* =================== wyszukiwarka: same pogrubione nazwy =================== */
function updateResults(){
  var box = $('results');
  var vis = sites.filter(siteVisible).slice();
  vis.sort(function(a,b){
    return ((a.arrivalY==null)-(b.arrivalY==null)) || ((a.arrivalY||9e3)-(b.arrivalY||9e3)) || a.name.localeCompare(b.name,'pl');
  });
  box.innerHTML = '';
  vis.forEach(function(s){
    var row = document.createElement('div');
    row.className = 'rrow';
    row.innerHTML = '<span class="rname">'+esc(s.name)+'</span>';
    row.addEventListener('click', function(){ seekToSite(s); });
    box.appendChild(row);
  });
}
(function wireSearch(){
  $('q').addEventListener('input', function(){
    fQ = this.value.trim();
    updateResults();
  });
  $('q').addEventListener('keydown', function(e){
    if(e.key==='Enter'){
      var first = $('results').querySelector('.rrow');
      if(first) first.click();
    }
  });
  $('btSearch').addEventListener('click', function(){ $('q').focus(); });
})();

/* =================== narzędzia (3 przyciski) =================== */
(function wireTools(){
  $('btLayer').addEventListener('click', function(){
    texKind = (texKind==='normal') ? 'heat' : 'normal';
    this.classList.toggle('on', texKind==='heat');
    this.title = texKind==='heat' ? 'Warstwa: heatmapa wysokości (kliknij: zwykła tekstura)'
                                  : 'Warstwa: zwykła tekstura (kliknij: heatmapa wysokości)';
    reliefOn = (texKind==='heat');
    globe.material.bumpScale = reliefOn? 0.012 : 0;
    region.seq++; region.busy = false;
    if(region.tex){ region.tex.dispose(); region.tex = null; }
    region.key=''; region.fails=0; region.lastFail=''; lastRegionT=-1;
    var t = hdTex[planetKey][texKind];
    if(t) applyNow(t);
    loadTextures(planetKey);
    applyRelief();
  });
  $('btRotate').addEventListener('click', function(){
    autoRotateOn = !autoRotateOn;
    this.classList.toggle('on', autoRotateOn);
    setAutoRotate();
  });
  $('btHome').addEventListener('click', function(){
    closePopup();
    homeView();
    setAutoRotate();
  });
  $('prReplay').addEventListener('click', function(){
    if(traverseData && selected){
      traverseData.played = false;
      startRoutePlay();
    }
  });
})();

/* =================== interakcje 3D =================== */
var downX=0, downY=0;
canvas.addEventListener('pointerdown', function(e){ downX=e.clientX; downY=e.clientY; canvas.classList.add('grabbing'); });
window.addEventListener('pointerup', function(){ canvas.classList.remove('grabbing'); });
canvas.addEventListener('click', function(e){
  if(Math.abs(e.clientX-downX)>6 || Math.abs(e.clientY-downY)>6) return;
  if(selected) closePopup();
});
controls.addEventListener('start', function(){ camAnim = null; });

/* =================== przełączanie planet =================== */
async function switchPlanet(key){
  if(!PLANETS) return;
  if(planet && planet.key===key && sites.length) return;
  closePopup();
  region.seq++; region.busy = false;
  if(region.tex){ region.tex.dispose(); region.tex = null; }
  region.key = ''; region.fails = 0; region.lastFail = ''; lastRegionT = -1;
  planet = PLANETS[key]; planetKey = key;
  document.body.dataset.planet = key;
  $('btMars').classList.toggle('on', key==='mars');
  $('btMoon').classList.toggle('on', key==='moon');
  playing = false; slide = null; setPlayIcon();
  $('q').value = ''; fQ = '';
  hdTex[key] = { normal:null, heat:null };
  flatMode = false; appliedL[key] = 0;
  globe.geometry = baseGeom;
  var fb = proceduralTexture(planet.fallbackColor, key);
  globe.material.map = fb; globe.material.bumpMap = fb;
  globe.material.bumpScale = reliefOn? 0.012 : 0;
  globe.material.needsUpdate = true;
  sites = []; events = []; traverseCache = {};
  clearRoute();
  try{
    sites = await loadSites(planet);
  }catch(e){
    console.warn('nie udało się pobrać danych (azmth.space + cache)', e);
    showLoading('BŁĄD: brak danych obiektów');
    setTimeout(hideLoading, 4000);
  }
  buildMarkers(); buildEvents(); buildTicks(); updateResults();
  /* oś startuje od pierwszego zdarzenia — prezentacja płynnie idzie do kolejnych */
  tPos = events.length? 0 : 0;
  year = posToYear(tPos);
  lastScrubIdx = -1;
  paintTime(); updateRouteProgress();
  homeView(); setAutoRotate();
  loadTextures(key);
  ensureHeights(key).then(function(){ if(reliefOn && planetKey===key) applyRelief(); });
  applyRelief();
  if(!bootDone){ bootDone = true; $('boot').classList.add('off'); }
}
$('btMars').addEventListener('click', function(){ switchPlanet('mars'); });
$('btMoon').addEventListener('click', function(){ switchPlanet('moon'); });

/* =================== resize + pętla =================== */
function resize(){
  var w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h); camera.aspect = w/h; camera.updateProjectionMatrix();
  viewShiftOn = false;   // offset widoku ustawiany co klatkę na nowo
}
window.addEventListener('resize', resize); resize();

var clock = new THREE.Clock();
var scaleBar = $('scaleBar'), scaleTxt = $('scaleTxt');
var lastScaleT = 0;
function niceNumber(v){
  var pow = Math.pow(10, Math.floor(Math.log10(v)));
  var f = v / pow;
  return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * pow;
}
function updateScale(camDist){
  if(clock.elapsedTime - lastScaleT < 0.15) return;
  lastScaleT = clock.elapsedTime;
  var kmppx = 2*Math.tan(camera.fov*Math.PI/360) * Math.max(camDist-1, 0.02)
              / (canvas.clientHeight||1) * planet.radiusKm;
  var val = niceNumber(kmppx * 100);
  var w = Math.max(24, Math.min(240, val / kmppx));
  scaleBar.style.width = w + 'px';
  scaleTxt.textContent = val >= 1 ? val + ' km' : Math.round(val*1000) + ' m';
}
function loop(){
  requestAnimationFrame(loop);
  var dt = clock.getDelta();

  /* płynne przesuwanie osi do kolejnego zdarzenia */
  if(slide){
    slide.t += dt/0.8;
    var k = easeIO(Math.min(1, slide.t));
    setPos(slide.from + (slide.to - slide.from)*k, 'slide');
    if(slide.t >= 1){ tPos = slide.to; slide = null; arriveAt(Math.round(tPos)); }
  } else if(playing && planet && events.length){
    dwellT -= dt;
    if(dwellT <= 0){ dwellT = 2.8; nextEvent(); }
  }

  /* odtwarzanie ruchu pojazdu po trasie */
  if(routePlay) stepRoutePlay(dt);

  if(skyMesh && skyMesh.visible) skyMesh.rotation.y += dt*0.004;
  if(camAnim && !routePlay){
    camera.position.lerp(camAnim.to, 0.07);
    if(camera.position.distanceTo(camAnim.to) < 0.01) camAnim = null;
  }

  /* planeta lekko na bok, gdy popup otwarty */
  var w = window.innerWidth, h = window.innerHeight;
  var wantShift = selected ? 1 : 0;
  _shift += (wantShift - _shift) * Math.min(1, dt*6);
  if(_shift > 0.004){
    camera.setViewOffset(w, h, w*0.105*_shift, 0, w, h);
    viewShiftOn = true;
  } else if(viewShiftOn){
    camera.clearViewOffset();
    viewShiftOn = false;
  }

  var camDist = camera.position.length();
  if(planet){
    updateRegion(camDist);
    if(region.fails >= 2 && hdTex[planetKey][texKind]){
      if(!flatMode && camDist < 1.10){
        flatMode = true;
        globe.material.map = null; globe.material.bumpMap = null; globe.material.needsUpdate = true;
      } else if(flatMode && camDist > 1.18){
        flatMode = false;
        setGlobeTex(hdTex[planetKey][texKind]);
      }
    }
    updateScale(camDist);
    updateMarkers();
    updateFrame();
  }
  controls.update();
  renderer.render(scene, camera);
}
var _shift = 0;

/* =================== start =================== */
loop();

/* Diagnostyczny bootstrap: każda faza ma własny komunikat błędu,
   żeby nie mylić błędu składni JSON / WebGL / file:// ze sobą. */
function bootFail(msg, e){
  if(e) console.error(e);
  var b = $('boot');
  if(!b) return;
  b.classList.add('err');
  var m = $('bootMsg');
  if(m){
    m.textContent = msg;
    if(e && e.message && msg.indexOf(String(e.message)) < 0){
      var d = document.createElement('div');
      d.className = 'bootDbg';
      d.textContent = '» ' + e.message;
      m.parentNode.appendChild(d);
    }
  }
}
(function cfgLoad(attempt){
  /* probujemy kilka ścieżek — działa gdy stronę serwuje się z katalogu
     nadrzędnego albo przy zagnieżdżonym rozpakowaniu zipa */
  var paths = ['nasa_data.json', './nasa_data.json', '../nasa_data.json'];
  var p = paths[attempt];
  if(!p) return bootFail('BŁĄD: nie znaleziono nasa_data.json w folderze ze stroną — index.html i nasa_data.json muszą leżeć obok siebie.');
  fetch(p, {cache:'no-cache'}).then(function(r){
    if(!r.ok) throw {http:r.status, url:p};
    return r.text();
  }).then(function(txt){
    /* jawny błąd składni z linią/kolumną — najczęstsza przyczyna:
       ręczna edycja nasa_data.json (przecinek, cudzysłów, nawias) */
    var j;
    try{ j = JSON.parse(txt); }
    catch(pe){
      var line = 1, col = 1, mm = /position (\d+)/.exec(pe.message);
      if(mm){
        var pos = +mm[1];
        line = txt.slice(0,pos).split('\n').length;
        col = pos - txt.lastIndexOf('\n', pos-1);
      }
      return bootFail('BŁĄD: nasa_data.json ma błąd składni JSON w linii ' + line + ', kolumnie ' + col + ' — sprawdź ostatnie zmiany (przecinek/cudzysłów/nawias).', pe);
    }
    DATA = j; API = j.api; TREK = j.trek; WMTS = j.wmts;
    META = j.missions; TYPE_PL = j.types; ALIAS = j.aliases || {};
    DUMPS = j.dumps || {}; HISTORY = j.history || {};
    PLANETS = j.planets;
    try{
      initSky();
      return switchPlanet('mars').then(function(){
        setTimeout(function(){
          if(!selected && events.length){
            playing = true; dwellT = 2.8; setPlayIcon();
            select(events[0].s, {demo:true});
          }
        }, 1200);
      }, function(e){
        bootFail('BŁĄD: inicjalizacja sceny 3D nie powiodła się (WebGL/tekstury/CDN three.js?).', e);
      });
    }catch(e){
      bootFail('BŁĄD: inicjalizacja sceny 3D nie powiodła się (WebGL/tekstury/CDN three.js?).', e);
    }
  }).catch(function(e){
    if(e && e.http){                       /* HTTP != 200 — spróbuj innej ścieżki */
      return cfgLoad(attempt + 1);
    }
    if(location.protocol === 'file:'){
      bootFail('BŁĄD: strona otwarta przez file:// — przeglądarka blokuje fetch. Uruchom w folderze ze stroną: python3 -m http.server 8000, potem otwórz http://localhost:8000', e);
    }else{
      bootFail('BŁĄD: nie udało się pobrać nasa_data.json — serwuj folder ze stroną przez: python3 -m http.server 8000', e);
    }
  });
})(0);

})();
